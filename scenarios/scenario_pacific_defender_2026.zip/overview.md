# Scenario: PACIFIC DEFENDER 2026
**Theater:** INDOPACOM — Western Pacific
**Adversary:** Near-peer state adversary (Pacific)

Multi-domain joint operation — air/maritime/space integration exercise with contested logistics and satellite coverage gaps.